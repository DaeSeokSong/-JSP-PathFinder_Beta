package ChattingClient;

import java.net.*;
import java.io.*;

public class MessageSender implements Runnable{
	
	Socket socket;
	String name;
	String msg;
	
	public MessageSender(Socket s, String m, String n) {
		this.socket = s;
		this.name = n;
		this.msg = m;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		 try {
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream()));
			
			while(true) {
				out.write("<" + "�̸�" + "> " + msg + "\n");
				out.flush();
				
				out.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("�޼��� ���� ����");
		}
	}   
	
}
