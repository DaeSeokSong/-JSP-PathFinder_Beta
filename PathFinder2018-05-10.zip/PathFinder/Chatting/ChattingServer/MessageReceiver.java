package ChattingServer;

import GUI.Client.MainClient;
import java.net.*;
import java.io.*;

public class MessageReceiver extends Server implements Runnable{
	
	Socket client;
	
	public MessageReceiver(Socket s) {
		this.client = s;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			
			while(true) {
				String msg = in.readLine();
				MainClient.chat.append(msg + "\n");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("�޼��� ���ù� ����");
		}
	}
	
}
