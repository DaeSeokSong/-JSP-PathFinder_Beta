package GUI.Server;

import java.util.ArrayList;

public class MainServer {
	
	static int ServerCode = 0;
	static ArrayList<User> UserList = new ArrayList<User>();
	
	class User{
		String name, id, password;
		
		public User(String name, String id, String password) {
			this.name = name;
			this.id = id;
			this.password = password;
		}
	}
	
	public void MainServerSet(int ServerCode) {
		this.ServerCode = ServerCode;
		
		if(ServerCode == 1) {
			Thread th1 = new Thread(new LoginServer());
			th1.start();
		}else if(ServerCode == 2) {
			Thread th2 = new Thread(new RegisterServerReceiver());
			th2.start();
		}
	}
		
}