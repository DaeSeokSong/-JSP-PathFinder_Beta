package Test20180421;

public class test {

	public static void main(String[] args) {
		int i;
		int j = 0;
		while((i = j) != 10) {
			System.out.println(i);
			j++;
		}
	}

}
