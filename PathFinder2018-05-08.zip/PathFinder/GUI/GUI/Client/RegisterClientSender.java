package GUI.Client;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;

public class RegisterClientSender implements Runnable{
	
	String NAME, ID, PASSWORD;
	
	public RegisterClientSender(String NAME, String ID, String PASSWORD) {
		this.NAME = NAME;
		this.ID = ID;
		this.PASSWORD = PASSWORD;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		try {
			Socket socket = new Socket();
			InetSocketAddress socketAddress = new InetSocketAddress("localhost", 8082);
			socket.connect(socketAddress, 5000);
			
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			
			out.write(NAME + "\n");
			out.write(ID + "\n");
			out.write(PASSWORD + "\n");
			out.flush();
			
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("�������� Ŭ���̾�Ʈ ���� ����");
		}
		
	}
	
}