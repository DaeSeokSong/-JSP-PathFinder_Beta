package GUI.Client;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import GUI.Server.MainServer;


public class RegisterInterface extends MainClient{
	
	public class MyActionListenerYes implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			JButton b = (JButton)e.getSource();
			if(b.getText().equals("Ȯ��")) {
				if(password_register.getText().equals("") || id_register.getText().equals("") || name_register.getText().equals("")) {
					new RegisterFailWindow2();
				}else if(password_register.getText().equals(passwordConfirm_register.getText())){
					MainServer RegisterServer = new MainServer();
					
					Thread th1 = new Thread(new RegisterClientSender(name_register.getText(), id_register.getText(), password_register.getText()));
					
					th1.start();
					RegisterServer.MainServerSet(2);
					dispose();
				}else {
					new RegisterFailWindow();
				}
			}
		}
	}
	
	public class MyActionListenerNo implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			JButton b = (JButton)e.getSource();
			if(b.getText().equals("���")) {
				dispose();
			}
		}
	}
	
	public RegisterInterface() {
		setTitle("PATH FINDER");
		setSize(500,300);
		setLocation(750,350);
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new GridLayout(5,2,10,12));
		contentPane.setBackground(Color.LIGHT_GRAY);
		
		contentPane.add(new JLabel("�̸�"));
		contentPane.add(name_register);
		contentPane.add(new JLabel("ID"));
		contentPane.add(id_register);
		contentPane.add(new JLabel("PASSWORD"));
		contentPane.add(password_register);
		contentPane.add(new JLabel("PASSWORD CONFIRM"));
		contentPane.add(passwordConfirm_register);
		
		JButton yes = new JButton("Ȯ��");
		JButton no = new JButton("���");
		yes.addActionListener(new MyActionListenerYes());
		no.addActionListener(new MyActionListenerNo());
		
		contentPane.add(yes);
		contentPane.add(no);
		
		setVisible(true);
	}
}
