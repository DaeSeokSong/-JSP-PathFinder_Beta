package GUI.Client;

import ChattingClient.Client;
import ChattingServer.Server;
import javax.swing.*;
import java.awt.*;

public class Main_WaitingRoomInterface extends MainClient{
	
	public Main_WaitingRoomInterface() {
		setTitle("PATH FINDER");
		setSize(1300,1000);
		setLocation(350,50);
		
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		JSplitPane splitPane2 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		JSplitPane splitPane3 = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		JSplitPane splitPane4 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		JSplitPane splitPane5 = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		Container contentPane = getContentPane();
		
		menu.setLayout(new GridLayout(10,1,10,60));
		menu.add(new JButton("������Ʈ"));
		menu.add(new JButton("����"));
		menu.add(new JButton("ģ��"));
		
		project_list.setLayout(new GridLayout(10,1,10,10));
		project_list.add(new JButton("Path_Finder"));
		
		msg.setMinimumSize(new Dimension(700,30));
		msg.setMaximumSize(new Dimension(700,30));
		chat.setMinimumSize(new Dimension(700,870));
		chat.setMaximumSize(new Dimension(700,870));
		menu.setMinimumSize(new Dimension(100,0));
		menu.setMaximumSize(new Dimension(100,0));
		user_list.setMinimumSize(new Dimension(150,400));
		user_list.setMaximumSize(new Dimension(150,400));
		project_list.setMinimumSize(new Dimension(150,400));
		project_list.setMaximumSize(new Dimension(150,400));
		file_list.setMinimumSize(new Dimension(200,0));
		file_list.setMaximumSize(new Dimension(200,0));
		
		splitPane3.setContinuousLayout(true);
		splitPane3.setBottomComponent(msg);
		splitPane3.setTopComponent(chat);
		splitPane.setDividerSize(5);
		
		splitPane5.setContinuousLayout(true);
		splitPane5.setBottomComponent(user_list);
		splitPane5.setTopComponent(project_list);
		splitPane.setDividerSize(5);
		
		splitPane.setContinuousLayout(true);
		splitPane.setLeftComponent(menu);
		splitPane.setRightComponent(splitPane5);
		splitPane.setDividerSize(15);
		
		splitPane2.setContinuousLayout(true);
		splitPane2.setLeftComponent(splitPane);
		splitPane2.setRightComponent(splitPane3);
		splitPane.setDividerSize(5);
		
		splitPane4.setContinuousLayout(true);
		splitPane4.setLeftComponent(splitPane2);
		splitPane4.setRightComponent(file_list);
		splitPane.setDividerSize(5);
		
		contentPane.add(splitPane4);
		
		setVisible(true);
	}
}
