package GUI.Server;

import javax.swing.*;
import java.awt.*;

public class LoginFailWindow2 extends JFrame{
	public LoginFailWindow2() {
		setTitle("PATH FINDER");
		setSize(300,100);
		setLocation(750,450);
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		contentPane.add(new JLabel("��ġ�ϴ� ���̵� �����ϴ�."));
		
		setVisible(true);
	}
}