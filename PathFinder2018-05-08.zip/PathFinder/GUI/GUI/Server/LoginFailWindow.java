package GUI.Server;

import javax.swing.*;
import java.awt.*;

public class LoginFailWindow extends JFrame{
	public LoginFailWindow() {
		setTitle("PATH FINDER");
		setSize(300,100);
		setLocation(750,450);
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		contentPane.add(new JLabel("��й�ȣ�� �ٽ� �Է����ּ���."));
		
		setVisible(true);
	}
}
