package ChattingClient;

import java.net.*;
import java.io.*;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		try {
			Socket socket = new Socket();
			InetSocketAddress socketAddress = new InetSocketAddress("localhost", 9090);
			socket.connect(socketAddress, 5000);
			 
	        System.out.println("���� ����!");
	        
	        Thread th = new Thread(new MessageSender(socket));
	        th.start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Ŭ���̾�Ʈ ����");
		}
		
	}

}
