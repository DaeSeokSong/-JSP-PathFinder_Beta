package ChattingServer;

import GUI.Client.*;
import java.util.*;
import java.net.*;
import java.io.*;

public class MessageReceiver extends MainClient implements Runnable {
	
	public static ArrayList <Socket> clientList = new ArrayList <Socket>();
	
	Socket client;
	
	public MessageReceiver(Socket s) {
		this.client = s;
		clientList.add(this.client);
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {	
			BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream(),"euc-kr"));
			DatagramSocket ds = new DatagramSocket();
			InetAddress ia = InetAddress.getLocalHost();
			
			while(true) {
				String msg = in.readLine();
				
				DatagramPacket data = new DatagramPacket(msg.getBytes(), msg.getBytes().length, ia, 40000);
				ds.send(data);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("�޼��� ���ù� ����");
			e.printStackTrace();
		}
	}
	
}
