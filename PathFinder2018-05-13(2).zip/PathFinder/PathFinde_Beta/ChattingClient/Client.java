package ChattingClient;

import java.net.*;
import java.util.*;
import java.io.*;

public class Client implements Runnable{
	
	static HashMap <String, Socket> clientList = new HashMap <String, Socket>();
	String msg;
	String name;
	
	public Client(String m,String n) {
		this.msg = m;
		this.name = n;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		try {
			Socket socket = new Socket();
			InetSocketAddress socketAddress = new InetSocketAddress("localhost", 9090);
			socket.connect(socketAddress, 5000);
			clientList.put(this.name, socket);
	        
	        Thread th = new Thread(new MessageSender(socket,this.msg,this.name));
	        th.start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("ä�� Ŭ���̾�Ʈ ����");
		}
		
	}
}