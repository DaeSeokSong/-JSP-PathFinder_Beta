package GUI.Client;

import java.util.*;
import javax.swing.*;

public class MainClient extends JFrame {
	
	ArrayList <String> UserList = new ArrayList <String>();
	
	//�α��� �������̽�
	JTextField id_login = new JTextField();
	JTextField password_login = new JPasswordField();
	
	//ȸ������ �������̽�
	JTextField name_register = new JTextField();
	JTextField id_register = new JTextField();
	JTextField password_register = new JPasswordField();
	JTextField passwordConfirm_register = new JPasswordField();
	
	public static void main(String[] args) {
		new LoginInterface();
	}

}
