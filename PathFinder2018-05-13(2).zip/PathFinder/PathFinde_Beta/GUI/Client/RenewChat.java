package GUI.Client;

import GUI.Client.*;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.*;
import java.util.Date;

public class RenewChat implements Runnable{

	String msg_receive;
	String user_name;
	Socket socket;
	
	public RenewChat(Socket s, String un) {
		this.socket = s;
		this.user_name = un;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		try {
			//���� �˸�
			Date now = new Date();
			Main_ProjectRoomClient.chat.append("<" + now + "> " + user_name + " ������Ʈ ����" + "\n");
			
			System.out.println(socket);
			
			DatagramSocket ds = new DatagramSocket(socket.getLocalPort());
			
			while(true) {
				byte[] bt = new byte[65508];
				DatagramPacket data = new DatagramPacket(bt, bt.length);
				System.out.println("�޼��� ��ٸ��� ��");
				ds.receive(data);
				
				InetAddress ia = data.getAddress();
				msg_receive = new String(data.getData()).trim();
				System.out.println("�޻��� ���� ����");
				System.out.println(msg_receive);
				
				Main_ProjectRoomClient.chat.append(msg_receive + "\n");
			}
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
