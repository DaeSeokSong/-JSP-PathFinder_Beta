package GUI.Client;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class RegisterFailWindow extends JFrame{
	public RegisterFailWindow() {
		setTitle("PATH FINDER");
		setSize(300,100);
		setLocation(850,450);
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		contentPane.add(new JLabel("��й�ȣ�� �ٽ� Ȯ�����ּ���."));
		
		setVisible(true);
	}
}
