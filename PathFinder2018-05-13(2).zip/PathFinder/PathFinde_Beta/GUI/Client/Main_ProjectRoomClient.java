/*
 * ChattingClient ����(MessageSender ����)��
 * �����÷��������̽��� �����ͼ� �״�� ������(������ ��� X)
 */
package GUI.Client;

import java.net.*;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.ScrollPaneConstants;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.*;

public class Main_ProjectRoomClient extends MainClient {
	
	public static String user_name;
	
	static JTextArea chat = new JTextArea(20,40);
	static DefaultListModel <String> model = new DefaultListModel <String>();
	
	JList user_list = new JList();
	
	JTextField msg = new JTextField(20);
	
	JToolBar menu = new JToolBar();
	JToolBar project_list = new JToolBar();
	
	JTree file_list = new JTree();
	
	JScrollPane user_board = new JScrollPane(user_list);
	JScrollPane chat_board = new JScrollPane(chat);
	
	String msg_send;
	
	int ThreadCheck = 0;
	
	public void setInterface() {
		//�������̽� ����
		setTitle("PATH FINDER");
		setSize(1300,1000);
		setLocation(350,50);
		
		setVisible(true);
		
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		JSplitPane splitPane2 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		JSplitPane splitPane3 = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		JSplitPane splitPane4 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		JSplitPane splitPane5 = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		Container contentPane = getContentPane();
	
		menu.setLayout(new GridLayout(10,1,10,60));
		menu.add(new JButton("������Ʈ"));
		menu.add(new JButton("����"));
		menu.add(new JButton("ģ��"));
	
		project_list.setLayout(new GridLayout(10,1,10,10));
		project_list.add(new JButton("Path_Finder"));
	
		// ��Ÿ ������
		chat.setBackground(new Color(250, 244, 192));
		chat.setEditable(false);
		
		chat_board.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		chat_board.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		user_board.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		user_board.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		
		//�ӽ�
		if(model.size() == 0) {
			model.insertElementAt(user_name, 0);
		}else{
			int i = 0;
			while(i == model.size()) i++;
			model.insertElementAt(user_name, i + 1);
		}
		
		user_list.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
		user_list.setVisibleRowCount(10);
		user_list.setModel(model);
		
		//������ ����
		msg.setMinimumSize(new Dimension(700,30));
		msg.setMaximumSize(new Dimension(700,30));
		chat_board.setMinimumSize(new Dimension(700,870));
		chat_board.setMaximumSize(new Dimension(700,870));
		menu.setMinimumSize(new Dimension(100,0));
		menu.setMaximumSize(new Dimension(100,0));
		user_board.setMinimumSize(new Dimension(150,400));
		user_board.setMaximumSize(new Dimension(150,400));
		project_list.setMinimumSize(new Dimension(150,400));
		project_list.setMaximumSize(new Dimension(150,400));
		file_list.setMinimumSize(new Dimension(200,0));
		file_list.setMaximumSize(new Dimension(200,0));
	
		// ���� ����
		splitPane3.setContinuousLayout(true);
		splitPane3.setBottomComponent(msg);
		splitPane3.setTopComponent(chat_board);
		splitPane.setDividerSize(5);
	
		splitPane5.setContinuousLayout(true);
		splitPane5.setBottomComponent(user_board);
		splitPane5.setTopComponent(project_list);
		splitPane.setDividerSize(5);
	
		splitPane.setContinuousLayout(true);
		splitPane.setLeftComponent(menu);
		splitPane.setRightComponent(splitPane5);
		splitPane.setDividerSize(15);
	
		splitPane2.setContinuousLayout(true);
		splitPane2.setLeftComponent(splitPane);
		splitPane2.setRightComponent(splitPane3);
		splitPane.setDividerSize(5);
	
		splitPane4.setContinuousLayout(true);
		splitPane4.setLeftComponent(splitPane2);
		splitPane4.setRightComponent(file_list);
		splitPane.setDividerSize(5);
	
		contentPane.add(splitPane4);
	}
	
	public Main_ProjectRoomClient() {
		// TODO Auto-generated method stub
		//Ŭ���̾�Ʈ ����
		try {
			Socket socket = new Socket();
			InetSocketAddress socketAddress = new InetSocketAddress("localhost", 9090);
			socket.connect(socketAddress, 5000);
			
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(),"euc-kr"));
			
			setInterface();
			
			if(ThreadCheck == 0) {
				//������
				new Thread(new RenewChat(socket,user_name)).start();
				ThreadCheck = 1;
			}
			
			// �޼��� �Է� ��
			msg.addKeyListener(new KeyAdapter() {
				public void keyPressed(KeyEvent e) {
					if(e.getKeyCode() == KeyEvent.VK_ENTER) {
						msg_send = msg.getText();
						
						try {
							out.write(user_name + " : "+msg_send + "\n");
							out.flush();
							
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							System.out.println("���� ������  ����");
						}
						msg.setText("");
					}
				}
			});
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			System.out.println("���� �ٲ� �ڵ� ����");
			e1.printStackTrace();
		}
	}
}