package ChattingServer;

import java.net.*;
import java.util.ArrayList;
import java.io.*;

public class Server{
	
	static ArrayList <Socket> clientList = new ArrayList <Socket>();
	
	public static void main(String[] args) {
		
		try {
			 System.out.println("������ ��ٸ��ϴ�.");
			 	
	         ServerSocket serverSocket = new ServerSocket();
	         InetSocketAddress socketAddress = new InetSocketAddress("localhost", 9090);
	         serverSocket.bind(socketAddress);
	         
	         AcceptThread acceptThread = new AcceptThread(serverSocket);
	         
	         // ���⼭ ���ο� �����尡 ����
	         new Thread(acceptThread).start();
	         
		} catch (IOException e) {
			// TODO Auto-generated catch block
		}
	}
}
