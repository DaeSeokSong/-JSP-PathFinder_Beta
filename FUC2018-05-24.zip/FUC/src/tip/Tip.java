package tip;

public class Tip {
	
	private int tipID;
	private String tipLang;
	private String tipTitle;
	private String userID;
	private String tipDate;
	private String tipContent;

	public int getTipID() {
		return tipID;
	}
	public void setTipID(int tipID) {
		this.tipID = tipID;
	}
	public String getTipLang() {
		return tipLang;
	}
	public void setTipLang(String tipLang) {
		this.tipLang = tipLang;
	}
	public String getTipTitle() {
		return tipTitle;
	}
	public void setTipTitle(String tipTitle) {
		this.tipTitle = tipTitle;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getTipDate() {
		return tipDate;
	}
	public void setTipDate(String tipDate) {
		this.tipDate = tipDate;
	}
	public String getTipContent() {
		return tipContent;
	}
	public void setTipContent(String tipContent) {
		this.tipContent = tipContent;
	}
	
}
