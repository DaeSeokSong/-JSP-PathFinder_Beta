package tip;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class TipDAO {
	private Connection conn;
	private ResultSet rs;
	
	public TipDAO() {
		try {
			String dbURL = "jdbc:mysql://osias.asuscomm.com:3307/FUC?serverTimezone=UTC";
			String dbID = "ejsvk2024";
			String dbPassword = "tlsthdrh21123";
			
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public String getDate() {
		String SQL = "SELECT NOW()";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				return rs.getString(1);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return ""; //�����ͺ��̽� ����
	}
	
	public int getNext() {
		String SQL = "SELECT tipID FROM TIP ORDER BY tipID DESC";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; //���簡 ù �Խù��� ���
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -1; //�����ͺ��̽� ����
	}
	
	public int write(String tipTitle, String userID, String tipContent, String tipLang) {
		String SQL = "INSERT INTO TIP VALUES (?, ?, ?, ?, ?, ?)";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, tipTitle);
			pstmt.setString(3, userID);
			pstmt.setString(4, getDate());
			pstmt.setString(5, tipContent);
			pstmt.setString(6, tipLang);
			
			return pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -1; //�����ͺ��̽� ����
	}
	
	public ArrayList<Tip> getList(int pageNumber){
		String SQL = "SELECT * FROM TIP WHERE tipID < ? ORDER BY tipID DESC LIMIT 10";
		ArrayList<Tip> list = new ArrayList<Tip>();
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				Tip tip = new Tip();
				tip.setTipID(rs.getInt(1));
				tip.setTipTitle(rs.getString(2));
				tip.setUserID(rs.getString(3));
				tip.setTipDate(rs.getString(4));
				tip.setTipContent(rs.getString(5));
				tip.setTipLang(rs.getString(6));
				list.add(tip);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public boolean nextPage(int pageNumber) {
		String SQL = "SELECT * FROM TIP WHERE tipID < ? ORDER BY tipID DESC LIMIT 10";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				return true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public Tip getTip(int tipID) {
		String SQL = "SELECT * FROM TIP WHERE tipID = ?";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, tipID);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				Tip tip = new Tip();
				tip.setTipID(rs.getInt(1));
				tip.setTipTitle(rs.getString(2));
				tip.setUserID(rs.getString(3));
				tip.setTipDate(rs.getString(4));
				tip.setTipContent(rs.getString(5));
				tip.setTipLang(rs.getString(6));
				
				return tip;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null; //�����ͺ��̽��� �ش� �Խñ� ���� �� ��
	}
	
	public int update(int tipID, String tipTitle, String tipContent, String tipLang) {
		String SQL = "UPDATE TIP SET tipTitle = ?, tipContent = ?, tipLang = ? WHERE tipID = ?";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, tipTitle);
			pstmt.setString(2, tipContent);
			pstmt.setString(3, tipLang);
			pstmt.setInt(4, tipID);
			
			return pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -1; //�����ͺ��̽� ����
	}
	
	public int delete(int tipID) {
		String SQL = "DELETE FROM TIP WHERE tipID = ?";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, tipID);
			
			return pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -1; //�����ͺ��̽� ����
	}
}
