package jobs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class JobsDAO {
	private Connection conn;
	private ResultSet rs;

	public JobsDAO() {
		try {
			String dbURL = "jdbc:mysql://osias.asuscomm.com:3307/FUC?serverTimezone=UTC";
			String dbID = "ejsvk2024";
			String dbPassword = "tlsthdrh21123";

			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getDate() {
		String SQL = "SELECT NOW()";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ""; // �����ͺ��̽� ����
	}

	public int getNext() {
		String SQL = "SELECT jobID FROM JOB ORDER BY jobID DESC";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; // ���簡 ù �Խù��� ���
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // �����ͺ��̽� ����
	}

	public int write(String jobTitle, String userID, String jobContent, String jobLang) {
		String SQL = "INSERT INTO JOB VALUES (?, ?, ?, ?, ?, ?)";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, jobTitle);
			pstmt.setString(3, userID);
			pstmt.setString(4, getDate());
			pstmt.setString(5, jobContent);
			pstmt.setString(6, jobLang);

			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // �����ͺ��̽� ����
	}

	public ArrayList<Jobs> getList(int pageNumber) {
		String SQL = "SELECT * FROM JOB WHERE jobID < ? ORDER BY jobID DESC LIMIT 10";
		ArrayList<Jobs> list = new ArrayList<Jobs>();

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Jobs job = new Jobs();
				job.setJobID(rs.getInt(1));
				job.setJobTitle(rs.getString(2));
				job.setUserID(rs.getString(3));
				job.setJobDate(rs.getString(4));
				job.setJobContent(rs.getString(5));
				job.setJobLang(rs.getString(6));
				list.add(job);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public boolean nextPage(int pageNumber) {
		String SQL = "SELECT * FROM JOB WHERE jobID < ? ORDER BY jobID DESC LIMIT 10";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public Jobs getJob(int comID) {
		String SQL = "SELECT * FROM JOB WHERE jobID = ?";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, comID);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				Jobs job = new Jobs();
				job.setJobID(rs.getInt(1));
				job.setJobTitle(rs.getString(2));
				job.setUserID(rs.getString(3));
				job.setJobDate(rs.getString(4));
				job.setJobContent(rs.getString(5));
				job.setJobLang(rs.getString(6));

				return job;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null; // �����ͺ��̽��� �ش� �Խñ� ���� �� ��
	}

	public int update(int jobID, String jobTitle, String jobContent, String jobLang) {
		String SQL = "UPDATE JOB SET jobTitle = ?, jobContent = ?, jobLang = ? WHERE jobID = ?";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, jobTitle);
			pstmt.setString(2, jobContent);
			pstmt.setString(3, jobLang);
			pstmt.setInt(4, jobID);

			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // �����ͺ��̽� ����
	}

	public int delete(int jobID) {
		String SQL = "DELETE FROM JOB WHERE jobID = ?";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, jobID);

			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // �����ͺ��̽� ����
	}
}
