package community;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class CommunityDAO {
	private Connection conn;
	private ResultSet rs;

	public CommunityDAO() {
		try {
			String dbURL = "jdbc:mysql://osias.asuscomm.com:3307/FUC?serverTimezone=UTC";
			String dbID = "ejsvk2024";
			String dbPassword = "tlsthdrh21123";

			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getDate() {
		String SQL = "SELECT NOW()";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ""; // �����ͺ��̽� ����
	}

	public int getNext() {
		String SQL = "SELECT comID FROM COM ORDER BY comID DESC";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; // ���簡 ù �Խù��� ���
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // �����ͺ��̽� ����
	}

	public int write(String comTitle, String userID, String comContent, String comLang) {
		String SQL = "INSERT INTO COM VALUES (?, ?, ?, ?, ?, ?)";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, comTitle);
			pstmt.setString(3, userID);
			pstmt.setString(4, getDate());
			pstmt.setString(5, comContent);
			pstmt.setString(6, comLang);

			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // �����ͺ��̽� ����
	}

	public ArrayList<Community> getList(int pageNumber) {
		String SQL = "SELECT * FROM COM WHERE comID < ? ORDER BY comID DESC LIMIT 10";
		ArrayList<Community> list = new ArrayList<Community>();

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Community com = new Community();
				com.setComID(rs.getInt(1));
				com.setComTitle(rs.getString(2));
				com.setUserID(rs.getString(3));
				com.setComDate(rs.getString(4));
				com.setComContent(rs.getString(5));
				com.setComLang(rs.getString(6));
				list.add(com);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public boolean nextPage(int pageNumber) {
		String SQL = "SELECT * FROM COM WHERE comID < ? ORDER BY comID DESC LIMIT 10";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public Community getCommunity(int comID) {
		String SQL = "SELECT * FROM COM WHERE comID = ?";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, comID);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				Community com = new Community();
				com.setComID(rs.getInt(1));
				com.setComTitle(rs.getString(2));
				com.setUserID(rs.getString(3));
				com.setComDate(rs.getString(4));
				com.setComContent(rs.getString(5));
				com.setComLang(rs.getString(6));

				return com;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null; // �����ͺ��̽��� �ش� �Խñ� ���� �� ��
	}

	public int update(int comID, String comTitle, String comContent, String comLang) {
		String SQL = "UPDATE COM SET comTitle = ?, comContent = ?, comLang = ? WHERE comID = ?";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, comTitle);
			pstmt.setString(2, comContent);
			pstmt.setString(3, comLang);
			pstmt.setInt(4, comID);

			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // �����ͺ��̽� ����
	}

	public int delete(int comID) {
		String SQL = "DELETE FROM COM WHERE comID = ?";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, comID);

			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // �����ͺ��̽� ����
	}
}
