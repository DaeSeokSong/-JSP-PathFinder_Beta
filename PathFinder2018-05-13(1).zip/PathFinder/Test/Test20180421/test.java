package Test20180421;

import java.util.Date;

public class test {

	public static void main(String[] args) {
		Date now = new Date();
		System.out.println(now);
	}

}
