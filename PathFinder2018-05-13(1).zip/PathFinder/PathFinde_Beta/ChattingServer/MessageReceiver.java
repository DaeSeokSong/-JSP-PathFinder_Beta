package ChattingServer;

import GUI.Client.*;
import java.util.*;
import java.net.*;
import java.io.*;

public class MessageReceiver extends Server implements Runnable {
	
	private Socket client;
	
	public MessageReceiver(Socket s) {
		this.client = s;
		clientList.add(this.client);
	}
	
    public void broadcast(String msg){
    	Collection collection = clientList;
    	Iterator iter = collection.iterator();
    	
    	while(iter.hasNext()) {
    		try {
    			Socket sk = (Socket)iter.next();
    			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(sk.getOutputStream())); 
    			bw.write(msg + "\n");	
    			bw.flush();
	
    			System.out.println("�޻��� ���� ����");
    		} catch (IOException e) {
    			// TODO Auto-generated catch block	
    			e.printStackTrace();	
    		}
    	}
    }
    
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(this.client.getInputStream(),"euc-kr"));
			
			while(true) {
				String name = in.readLine();
				String msg = in.readLine();
				System.out.println(name + " : " + msg);
		    	System.out.println(clientList.size());
				broadcast(name + " : " + msg);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("�޼��� ���ù� ����");
			e.printStackTrace();
		}
	}
	
}
