package GUI.Client;
import GUI.Server.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import GUI.Client.LoginInterface.MyActionListenerLogin;
import GUI.Client.LoginInterface.MyActionListenerRegister;
import GUI.Server.LoginServerSender;

public class LoginInterface extends MainFuntion{
	public class MyActionListenerRegister implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			JButton b = (JButton)e.getSource();
			if(b.getText().equals("ȸ������")) new RegisterInterface(); 
		}
	}
	
	public class MyActionListenerLogin implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			JButton b = (JButton)e.getSource();
			if(b.getText().equals("�α���")) {
				
				Thread th1 = new Thread(new LoginServerSender());	
				Thread th2 = new Thread(new LoginClientSender(id.getText(),password.getText()));
				Thread th3 = new Thread(new LoginClientReceiver());
				
				th2.start();
				th1.start();
				th3.start();
				
			}
		}
	}
	
	public LoginInterface() {
		setTitle("PATH FINDER");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500,300);
		setLocation(750,350);
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new GridLayout(3,2,10,75));
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.add(new JLabel("ID"));
		contentPane.add(id);
		contentPane.add(new JLabel("PASSWORD"));
		contentPane.add(password);
		JButton login = new JButton("�α���");
		login.addActionListener(new MyActionListenerLogin());
		contentPane.add(login);
		JButton register = new JButton("ȸ������");
		register.addActionListener(new MyActionListenerRegister());
		contentPane.add(register);
		
		setVisible(true);
	}
}
