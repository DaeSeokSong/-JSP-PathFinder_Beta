package GUI.Client;
import java.awt.*;
import javax.swing.*;

public class RegisterInterface extends MainFuntion{
	public RegisterInterface() {
		setTitle("PATH FINDER");
		setSize(500,300);
		setLocation(750,350);
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new GridLayout(5,2,10,12));
		contentPane.setBackground(Color.LIGHT_GRAY);
		
		contentPane.add(new JLabel("�̸�"));
		contentPane.add(new JTextField(""));
		contentPane.add(new JLabel("ID"));
		contentPane.add(new JTextField(""));
		contentPane.add(new JLabel("PASSWORD"));
		contentPane.add(new JPasswordField(""));
		contentPane.add(new JLabel("PASSWORD CONFIRM"));
		contentPane.add(new JPasswordField(""));
		contentPane.add(new JButton("Ȯ��"));
		contentPane.add(new JButton("���"));
		
		setVisible(true);
	}
}
