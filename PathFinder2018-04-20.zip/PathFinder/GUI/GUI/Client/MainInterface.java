package GUI.Client;
import java.util.*;
import javax.swing.*;
import java.awt.*;

public class MainInterface extends MainFuntion{
	public MainInterface() {
		setTitle("PATH FINDER");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(800,600);
		setLocation(600,250);
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		contentPane.add(new JButton("���� ȭ��"), BorderLayout.CENTER);
		
		setVisible(true);
	}
}
