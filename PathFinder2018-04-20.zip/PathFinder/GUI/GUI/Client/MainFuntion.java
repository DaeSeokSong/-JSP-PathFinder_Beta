package GUI.Client;
import javax.swing.*;

public class MainFuntion extends JFrame{
	
	JTextField id = new JTextField();
	JTextField password = new JPasswordField();
	
	public static void main(String[] args) {
		new LoginInterface();
	}

}
