package GUI.Server;
import java.util.*;
import javax.swing.*;
import GUI.Client.*;

import java.awt.*;

public class LoginFailWindow extends MainFuntion{
	public LoginFailWindow() {
		setTitle("PATH FINDER");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300,100);
		setLocation(700,350);
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		contentPane.add(new JLabel("�Է»����� �ٽ� Ȯ�����ּ���."));
		
		setVisible(true);
	}
}
