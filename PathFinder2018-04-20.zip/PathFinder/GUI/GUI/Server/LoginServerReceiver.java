package GUI.Server;
import GUI.Client.*;
import java.util.*;
import java.net.*;
import java.io.*;

public class LoginServerReceiver implements Runnable{
	
	class User{
		private String id, password;
		
		public User(String id, String password) {
			this.id = id;
			this.password = password;
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
}
