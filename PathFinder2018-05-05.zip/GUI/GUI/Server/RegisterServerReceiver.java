package GUI.Server;
import java.net.*;
import java.io.*;

public class RegisterServerReceiver extends MainServer implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			//���� ��� �غ�
			ServerSocket listener1 = new ServerSocket(); //RegisterClientSender
			InetSocketAddress socketAddress1 = new InetSocketAddress("localHost", 8082);
			listener1.bind(socketAddress1);
			//���� �Ϸ�
			Socket socket1 = listener1.accept();
			
			//ȸ������ �����ϰ� LoginServerSender�� ���� ������ ����
			BufferedReader in = new BufferedReader(new InputStreamReader(socket1.getInputStream()));
			FileWriter fout = new FileWriter("K:\\Eclipse\\Project\\PathFinder\\GUI\\GUI\\Server\\UserList.txt");
			
			String NAME = in.readLine();
			String ID = in.readLine();
			String PASSWORD = in.readLine();
			
			fout.write(ID + "\n");
			fout.write(PASSWORD + "\n");
			fout.write(NAME + "\n");
			
			System.out.println(NAME);
			System.out.println(ID);
			System.out.println(PASSWORD);
			
			UserList.add(new User(NAME, ID, PASSWORD));
			
			for(int i = 0; i < UserList.size(); i++) {
				System.out.println(UserList.get(i).name);
				System.out.println(UserList.get(i).id);
				System.out.println(UserList.get(i).password);
			}
			
			fout.close();
			socket1.close();
			listener1.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("�������� ���� ���ù� ����");
		} 
		
	}
}
