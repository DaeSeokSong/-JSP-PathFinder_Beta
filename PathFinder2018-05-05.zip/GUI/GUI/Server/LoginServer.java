package GUI.Server;
import java.net.*;
import java.io.*;

public class LoginServer extends MainServer implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			//���� ��� �غ�
			ServerSocket listener1 = new ServerSocket(); //LoginClientSender
			ServerSocket listener2 = new ServerSocket(); //LoginClientReceiver
			InetSocketAddress socketAddress1 = new InetSocketAddress("localHost", 8080);
			InetSocketAddress socketAddress2 = new InetSocketAddress("localHost", 8081);
			listener1.bind(socketAddress1);
			listener2.bind(socketAddress2);
			//���� �Ϸ�
			Socket socket1 = listener1.accept();
			Socket socket2 = listener2.accept();
			
			//�α��� �� ������ ��ϵ� ������ Ŭ���̾�Ʈ�� �Էµ� ���� ���ϴ� ���� �ڵ�
			BufferedReader in = new BufferedReader(new InputStreamReader(socket1.getInputStream())); //LoginClientSender �� ���� �α��� �Է»��� �޾ƿ�
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket2.getOutputStream())); //LoginClientReceiver �� �α��� ���� ���� ����
			FileReader fin = new FileReader("K:\\Eclipse\\Project\\PathFinder\\GUI\\GUI\\Server\\UserList.txt");
			
			String LoginId = in.readLine();
			String LoginPassword = in.readLine();
			String UserId = "";
			String UserPassword = "";
			
			char cUserCheck;
			int iUserCheck = 0;
			int LoginCheck = 0;
			
			System.out.println(LoginId);
			System.out.println(LoginPassword);
			while(true) {
				
				iUserCheck = fin.read();
				while(iUserCheck != -1) {
					cUserCheck = (char)iUserCheck;
					while(cUserCheck != '\n') {
						System.out.println(cUserCheck);
						UserId = UserId + cUserCheck;
						iUserCheck = fin.read();
						cUserCheck = (char)iUserCheck;
					}
					iUserCheck = fin.read();
					System.out.println(UserId);
					if(LoginId.equals(UserId)) {
						LoginCheck++;
						break;
					}
				}
				
				while(iUserCheck != -1) {
					cUserCheck = (char)iUserCheck;
					while(cUserCheck != '\n') {
						System.out.println(cUserCheck);
						UserPassword = UserPassword + cUserCheck;
						iUserCheck = fin.read();
						cUserCheck = (char)iUserCheck;
					}
					iUserCheck = fin.read();
					System.out.println(UserPassword);
					if(LoginPassword.equals(UserPassword)) {
						LoginCheck++;
						break;
					}
				}
				
				if(LoginCheck == 2) {
					out.write("����");
					out.flush();
					break;
				}else {
					out.write("���㰡");
					out.flush();
					new LoginFailWindow();
					break;
				}
				
			}
			
			fin.close();
			socket1.close();
			socket2.close();
			listener1.close();
			listener2.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("�α��� ���� Ŭ���� ���Ͽ� ���� ����");
		}
	}
}
