package GUI.Client;
import GUI.Server.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class LoginInterface extends MainClient{
	
	public class MyActionListenerRegister implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			JButton b = (JButton)e.getSource();
			if(b.getText().equals("ȸ������")) new RegisterInterface(); 
		}
	}
	
	public class MyActionListenerLogin implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			JButton b = (JButton)e.getSource();
			if(b.getText().equals("�α���")) {
				dispose();
				MainServer InterfaceServer = new MainServer();
				
				Thread th2 = new Thread(new LoginClientSender(id_login.getText(),password_login.getText()));
				Thread th3 = new Thread(new LoginClientReceiver());
				
				th2.start();
				InterfaceServer.MainServerSet(1);
				th3.start();
			}
		}
	}
	
	public LoginInterface() {
		setTitle("PATH FINDER");
		setSize(500,300);
		setLocation(750,350);
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new GridLayout(3,2,10,75));
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.add(new JLabel("ID"));
		contentPane.add(id_login);
		contentPane.add(new JLabel("PASSWORD"));
		contentPane.add(password_login);
		
		JButton login = new JButton("�α���");
		JButton register = new JButton("ȸ������");
		login.addActionListener(new MyActionListenerLogin());
		register.addActionListener(new MyActionListenerRegister());
		
		contentPane.add(login);
		contentPane.add(register);
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new LoginInterface();
	}
}
