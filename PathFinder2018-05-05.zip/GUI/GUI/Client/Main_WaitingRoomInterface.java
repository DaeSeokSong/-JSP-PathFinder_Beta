package GUI.Client;
import java.util.*;
import javax.swing.*;
import java.awt.*;

public class Main_WaitingRoomInterface extends MainClient{
	
	JSplitPane splitPane;
	
	public Main_WaitingRoomInterface() {
		setTitle("PATH FINDER");
		setSize(800,600);
		setLocation(600,250);
		
		splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		contentPane.add(splitPane, BorderLayout.WEST);
		
		setVisible(true);
	}
}
