package ChattingClient;

import java.net.*;
import java.util.Scanner;
import java.io.*;

public class MessageSender implements Runnable{
	
	Socket socket;
	
	public MessageSender(Socket s) {
		this.socket = s;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		 try {
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			
			while(true) {
				Scanner sc = new Scanner(System.in);
				String msg = sc.nextLine();
				
				out.write(msg + "\n");
				out.flush();
				
				if(msg.equals("q")) {
					sc.close();
		        	socket.close();
					break;
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("�޼��� ���� ����");
		}
	}
	
}
