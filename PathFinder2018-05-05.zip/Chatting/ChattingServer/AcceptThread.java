package ChattingServer;

import java.net.*;

public class AcceptThread extends Server implements Runnable{
	ServerSocket serverSocket;
    Socket client;
    
    public AcceptThread(ServerSocket serverSocket) {
        this.serverSocket = serverSocket;
    }
 
    @Override
    public void run() {
    	
    	try {
    		while(true) {
    			client = serverSocket.accept();
            	System.out.println("connected client"+ client);
                
            	new Thread(new MessageReceiver(client)).start();
            	
            	clientList.add(client);
            	
    		}
        } catch (Exception e) {
                // TODO: handle exception
        }
    }
}
