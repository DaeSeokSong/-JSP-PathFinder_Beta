package ChattingServer;

import java.net.*;
import java.io.*;

public class MessageReceiver extends Server implements Runnable{
	
	Socket client;
	
	public MessageReceiver(Socket s) {
		this.client = s;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			
			while(true) {
				String msg = in.readLine();
				
				if(msg.equals("q")) {
	        		System.out.println("������ ����Ǿ����ϴ�.");
	        		client.close();
	        		break;
	        	}
	        	
	        	System.out.println("<Ŭ���̾�Ʈ> :" + msg);
	        	
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("�޼��� ���ù� ����");
		}
	}
	
}
