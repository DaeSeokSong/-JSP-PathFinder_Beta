package GUI.Client;

import java.net.*;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JSplitPane;

import GUI.Server.LoginServerSub;
import GUI.Server.LoginServerSub2;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.*;

public class Main_ProjectRoomClient extends MainClient {
	
	String user_name;
	String msg_send;
	
	public Main_ProjectRoomClient(String s) {
		user_name = s;
	}
	
	public Main_ProjectRoomClient() {
		// TODO Auto-generated method stub
		//Ŭ���̾�Ʈ ����
		try {
			//Ŭ���̾�Ʈ�� ��Ƽ ������ �������� �ٲ����
			Socket socket = new Socket();
			InetSocketAddress socketAddress = new InetSocketAddress("localhost", 9090);
			socket.connect(socketAddress, 5000);
			
			System.out.println(USERNAME);
			new LoginServerSub(USERNAME);
			new LoginServerSub2(USERNAME); // �� �κ� ���ľ� ��
			
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
		
			System.out.println(user_name);
			//�������̽� ����
			setTitle("PATH FINDER");
			setSize(1300,1000);
			setLocation(350,50);
		
			JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
			JSplitPane splitPane2 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
			JSplitPane splitPane3 = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
			JSplitPane splitPane4 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
			JSplitPane splitPane5 = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
			Container contentPane = getContentPane();
		
			menu.setLayout(new GridLayout(10,1,10,60));
			menu.add(new JButton("������Ʈ"));
			menu.add(new JButton("����"));
			menu.add(new JButton("ģ��"));
		
			project_list.setLayout(new GridLayout(10,1,10,10));
			project_list.add(new JButton("Path_Finder"));
		
			// ��Ÿ ������
			chat.setBackground(new Color(250, 244, 192));
			user_list.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			user_list.setVisibleRowCount(10);
			user_list.setModel(model);
		
			msg.addKeyListener(new KeyAdapter() {
				public void keyPressed(KeyEvent e) {
					if(e.getKeyCode() == KeyEvent.VK_ENTER) {
						msg_send = msg.getText();
						try {
							out.write("<" + user_name + "> " + msg_send + "\n");
							out.flush();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							System.out.println("���� ����");
						}
						msg.setText("");
						/*
						 * ChattingClient ����(MessageSender ����)��
						 * �����÷��������̽��� �����ͼ� �״�� ������(������ ��� X)
						 */
					}
				}
			});
			
			//������ ����
			msg.setMinimumSize(new Dimension(700,30));
			msg.setMaximumSize(new Dimension(700,30));
			chat_board.setMinimumSize(new Dimension(700,870));
			chat_board.setMaximumSize(new Dimension(700,870));
			menu.setMinimumSize(new Dimension(100,0));
			menu.setMaximumSize(new Dimension(100,0));
			user_board.setMinimumSize(new Dimension(150,400));
			user_board.setMaximumSize(new Dimension(150,400));
			project_list.setMinimumSize(new Dimension(150,400));
			project_list.setMaximumSize(new Dimension(150,400));
			file_list.setMinimumSize(new Dimension(200,0));
			file_list.setMaximumSize(new Dimension(200,0));
		
			// ���� ����
			splitPane3.setContinuousLayout(true);
			splitPane3.setBottomComponent(msg);
			splitPane3.setTopComponent(chat_board);
			splitPane.setDividerSize(5);
		
			splitPane5.setContinuousLayout(true);
			splitPane5.setBottomComponent(user_board);
			splitPane5.setTopComponent(project_list);
			splitPane.setDividerSize(5);
		
			splitPane.setContinuousLayout(true);
			splitPane.setLeftComponent(menu);
			splitPane.setRightComponent(splitPane5);
			splitPane.setDividerSize(15);
		
			splitPane2.setContinuousLayout(true);
			splitPane2.setLeftComponent(splitPane);
			splitPane2.setRightComponent(splitPane3);
			splitPane.setDividerSize(5);
		
			splitPane4.setContinuousLayout(true);
			splitPane4.setLeftComponent(splitPane2);
			splitPane4.setRightComponent(file_list);
			splitPane.setDividerSize(5);
		
			contentPane.add(splitPane4);
		
			setVisible(true);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			System.out.println("���� �ٲ� �ڵ� ����");
		}
	}
}