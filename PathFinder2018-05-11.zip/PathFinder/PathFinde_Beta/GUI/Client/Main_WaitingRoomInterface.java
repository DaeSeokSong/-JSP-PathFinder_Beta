package GUI.Client;

import ChattingServer.Server;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;

public class Main_WaitingRoomInterface extends MainClient{
	
	public Main_WaitingRoomInterface() {
		
	}
}
