package GUI.Client;

import java.util.*;
import javax.swing.*;

public class MainClient extends JFrame {
	
	ArrayList <String> UserList = new ArrayList <String>();
	
	//�α��� �������̽�
	JTextField id_login = new JTextField();
	JTextField password_login = new JPasswordField();
	
	//ȸ������ �������̽�
	JTextField name_register = new JTextField();
	JTextField id_register = new JTextField();
	JTextField password_register = new JPasswordField();
	JTextField passwordConfirm_register = new JPasswordField();
	
	//����-���� �������̽�
	String USERNAME;
	
	JTextArea chat = new JTextArea(20,40);
	
	DefaultListModel <String> model = new DefaultListModel <String>();
	
	JList user_list = new JList();
	
	JTextField msg = new JTextField(20);
	
	JToolBar menu = new JToolBar();
	JToolBar project_list = new JToolBar();
	
	JTree file_list = new JTree();
	
	JScrollPane chat_board = new JScrollPane(chat);
	JScrollPane user_board = new JScrollPane(user_list);
	
	//����-ä�� �������̽�
	JTextField chat_msg = new JTextField();
	
	public class outputChatting {
		public outputChatting(String s) {
			chat.append(s + "\n");
		}
	}
	
	public class addListElement {
		public addListElement(String s) {
			model.addElement(s);
		}
	}
	
	public static void main(String[] args) {
		new LoginInterface();
	}

}
