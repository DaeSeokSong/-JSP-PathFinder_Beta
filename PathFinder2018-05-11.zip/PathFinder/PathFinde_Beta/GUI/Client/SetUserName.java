package GUI.Client;

public class SetUserName extends MainClient{

	public SetUserName(String s) {
		USERNAME = s;
	}
}
