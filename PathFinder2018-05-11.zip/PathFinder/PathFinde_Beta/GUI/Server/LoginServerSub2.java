package GUI.Server;

import GUI.Client.Main_ProjectRoomClient;

public class LoginServerSub2 extends Main_ProjectRoomClient{
	
	public LoginServerSub2(String s) {
		super(s);
		System.out.println(s);
	}

}
