package GUI.Server;

import ChattingServer.AcceptThread;

public class LoginServerSub extends AcceptThread{
	
	public LoginServerSub(String s) {
		super(s);
		System.out.println(s);
	}

}
