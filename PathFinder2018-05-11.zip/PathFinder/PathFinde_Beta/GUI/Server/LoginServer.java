package GUI.Server;

import GUI.Client.*;
import java.net.*;
import java.io.*;

public class LoginServer extends MainServer implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			//���� ��� �غ�
			ServerSocket listener1 = new ServerSocket(); //LoginClientSender
			ServerSocket listener2 = new ServerSocket(); //LoginClientReceiver
			InetSocketAddress socketAddress1 = new InetSocketAddress("localHost", 8080);
			InetSocketAddress socketAddress2 = new InetSocketAddress("localHost", 8081);
			listener1.bind(socketAddress1);
			listener2.bind(socketAddress2);
			//���� �Ϸ�
			Socket socket1 = listener1.accept();
			Socket socket2 = listener2.accept();
			
			//�α��� �� ������ ��ϵ� ������ Ŭ���̾�Ʈ�� �Էµ� ���� ���ϴ� ���� �ڵ�
			BufferedReader in = new BufferedReader(new InputStreamReader(socket1.getInputStream())); //LoginClientSender �� ���� �α��� �Է»��� �޾ƿ�
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket2.getOutputStream())); //LoginClientReceiver �� �α��� ���� ���� ����
			//FileReader fin = new FileReader("K:\\Eclipse\\Project\\PathFinder\\PathFinde_Beta\\GUI\\Server\\UserList.txt");
			File file = new File("K:\\Eclipse\\Project\\PathFinder\\PathFinde_Beta\\GUI\\Server\\UserList.txt");
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file),"euc-kr"));
			
			String LoginId = in.readLine();
			String LoginPassword = in.readLine();
			String UserId = "";
			String UserPassword = "";
			String UserName = "";
			String Info = "";
			
			int LoginCheck = 1;
			
			/*char cUserCheck;
			int iUserCheck = 0;*/
			
			System.out.println(LoginId); //����� ��
			System.out.println(LoginPassword); //����� ��
			
			/*iUserCheck = fin.read();
			while(iUserCheck != -1) {
				cUserCheck = (char)iUserCheck;
				while(cUserCheck != '\n') {
					System.out.println(cUserCheck); //����� ��
					UserId = UserId + cUserCheck;
					iUserCheck = fin.read();
					cUserCheck = (char)iUserCheck;
				}
				iUserCheck = fin.read();
				System.out.println(UserId); //����� ��
				
				if(LoginId.equals(UserId)) {
					cUserCheck = (char)iUserCheck;
					while(cUserCheck != '\n') {
						System.out.println(cUserCheck); //����� ��
						UserPassword = UserPassword + cUserCheck;
						iUserCheck = fin.read();
						cUserCheck = (char)iUserCheck;
					}
					System.out.println(UserPassword); //����� ��
					
					if(LoginPassword.equals(UserPassword)) {
						out.write("����");
						out.flush();
						iUserCheck = fin.read();
						cUserCheck = (char)iUserCheck;
						while(cUserCheck != '\n') {
							System.out.println(cUserCheck); //����� ��
							UserName = UserName + cUserCheck;
							iUserCheck = fin.read();
							cUserCheck = (char)iUserCheck;
						}
						System.out.println(UserName);
						new SetUserName(UserName); //���⼭ ���� ���� ����
					}else {
						out.write("���㰡");
						out.flush();
						new LoginFailWindow();
					}
					break;
				}else if(iUserCheck == -1) {
					out.write("���㰡");
					out.flush();
					new LoginFailWindow2();
				}
				UserId = "";
			}*/
			
			Info = br.readLine();
			while(Info != null) {
				UserId = Info;
				System.out.println(UserId);
				if(UserId.equals(LoginId)) {
					UserPassword = br.readLine();
					System.out.println(UserPassword);
					if(UserPassword.equals(LoginPassword)) {
						UserName = br.readLine();
						System.out.println(UserName);
						new SetUserName(UserName);
						
						out.write("����");
						out.flush();
						break;
					}else {
						out.write("���㰡");
						out.flush();
						new LoginFailWindow();
						break;
					}
				}else {
					Info = br.readLine();
					if(Info == null) LoginCheck = 0;
				}
			}
			if(LoginCheck == 0) {
				out.write("���㰡");
				out.flush();
				new LoginFailWindow2();
			}
			
			//fin.close();
			br.close();
			socket1.close();
			socket2.close();
			listener1.close();
			listener2.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("�α��� ���� Ŭ���� ���Ͽ� ���� ����");
		}
	}
}
