package ChattingServer;

import GUI.Client.MainClient;
import java.net.*;
import java.io.*;

public class MessageReceiver extends MainClient implements Runnable{
	
	Socket client;
	
	public MessageReceiver(Socket s) {
		this.client = s;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			
			while(true) {
				String msg = in.readLine();
				System.out.println(msg);
				
				new outputChatting(msg);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("�޼��� ���ù� ����");
		}
	}
	
}
